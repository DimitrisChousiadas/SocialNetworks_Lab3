function r = beta(t)

     r = 2 - 1.8*cos(5*t);
